export class Todo {
  id: string;
  title: string;
  address: string;
  city: string;
  state: string;
  country: string;
  zip: string;
  completed: boolean;
  createdAt: Date;
}
